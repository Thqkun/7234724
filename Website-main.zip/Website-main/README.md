<p align="center">
	<img width="755" height="175" src="assets/images/logo.png">
</p>

# Info
Packet Client is an MCBE Utility mod made by: Packet, Deq, Swed, NRG and Founder

Packet Client is a fork of the Horion Client


## Credits

The original Horion developers

Steve's Noob#2585
